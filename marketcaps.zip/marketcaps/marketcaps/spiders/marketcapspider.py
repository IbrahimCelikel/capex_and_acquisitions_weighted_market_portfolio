import scrapy
import pandas as pd
import csv

class MarketcapspiderSpider(scrapy.Spider):
    name = "marketcapspider"
    allowed_domains = ["companiesmarketcap.com"]
    start_urls = ["https://companiesmarketcap.com/"]



    def parse(self, response):
        urls = pd.read_csv("C:/depo/repositories/sp500 r&d based market portfolio/market_caps/urls.csv")
        for url in urls['url']:
            yield response.follow(url, callback= self.parse_company_page)
            
    def parse_company_page(self, response):
        ticker = response.css('div[class="company-title-container"] div[class="company-code"]::text').getall()
        
        file_path = "C:/depo/repositories/sp500 r&d based market portfolio/market_caps/" + ticker[0] + ".csv"
        
        trs = response.css('*[class="table"] tbody tr')
        
        for tr in trs:
            row = tr.css('td::text').getall()

            file = open(file_path, "a", newline='')
            writer = csv.writer(file)
            writer.writerow([row])
            file.close()